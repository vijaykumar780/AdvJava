import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class OptionalClass {
    public static void main(String ar[]) {
        Optional<String> opt = Optional.empty();
        if (opt.isPresent()) {
            System.out.println("Optional not empty");
        }

        opt = Optional.of("wlp");
        if (opt.isPresent()) {
            System.out.println("Optional not empty");
        }
        Tmp tmp = null;
        Optional<Integer> optionalInteger = Optional.ofNullable(null);

        Integer val = 5;
        Integer optInt = Optional.ofNullable(val).orElse(50);
        System.out.println(optInt);

        val = null;
        optInt = Optional.ofNullable(val).orElse(50);
        System.out.println(optInt);

        List<Integer> lst = Arrays.asList(1,5,2,3,4);
        List<Integer> sortedLst = lst.stream().sorted().collect(Collectors.toList());
        System.out.println(sortedLst);

        Integer [] intArray = new Integer[5];
        intArray[0] = 3;
        intArray[1] = 2;
        intArray[2] = 4;
        intArray[3] = 1;
        intArray[4] = 5;

        Arrays.sort(intArray);
        System.out.println(Arrays.asList(intArray));
    }
}

class Tmp {
    public Integer getW() {
        return w;
    }

    public void setW(Integer w) {
        this.w = w;
    }

    Integer w;
    Tmp(Integer w) {
        this.w=w;
    }
}
