import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Lists {
    public static void main (String ar[]) {

        // All collections have methods add, remove, contains, clear, size, isEmpty
        List<String> ls = new ArrayList<>();
        ls.add("ab");
        ls.add("cd");
        ls.add("ef");
        ls.add("gh");
        ls.remove(0);
        ls.remove(0);

        int i;
        for (i = 0; i < ls.size(); i++) {
            System.out.println(ls.get(i));
        }
        ls.clear();
        System.out.println(ls);
        System.out.println(ls.isEmpty());

        List<String> ll = new LinkedList<>();
        List<String> ll2 = new LinkedList<>();
        ll2.add("ll21");
        ll.add("wl");
        ll.add(0,"mn");
        System.out.println(ll);

        ll.addAll(ll2);
        ll.remove(1);
        System.out.println(ll);

        // Linked list are not thread safe
        List<String> synchronizedList = Collections.synchronizedList(ll);
        System.out.println(synchronizedList);
    }
}
