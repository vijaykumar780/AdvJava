import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class LocalDateTimeImpl {
    public static void main(String [] ar) {
        LocalDate ld = LocalDate.now();
        LocalDate ld1 = LocalDate.of(2023,5,1);
        System.out.println(ld);
        System.out.println(ld1);
        System.out.println(ld1.getDayOfMonth());
        System.out.println(ld.isAfter(ld1));

        LocalTime lt = LocalTime.now();
        LocalTime lt2 = LocalTime.of(5,21,21);
        System.out.println(lt);
        System.out.println(lt2);
        System.out.println(lt2.getHour());

        java.time.LocalDateTime ldt = java.time.LocalDateTime.now();
        System.out.println(ldt);

        ZonedDateTime zdt = ZonedDateTime.now();
        System.out.println(zdt);
        System.out.println(zdt.getZone());

        DateTimeFormatter dtf = DateTimeFormatter.ISO_LOCAL_DATE;
        System.out.println(dtf.format(ldt));
        dtf = DateTimeFormatter.ofPattern("dd/MMM/yyyy");

        String date = "25-10-2023";
        dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate parsedDate = LocalDate.parse(date, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        System.out.println("Parsed "+ parsedDate);

        System.out.println(dtf.format(ldt));
        java.time.LocalDateTime ldt2 = ldt.plusDays(10);
        System.out.println(dtf.format(ldt2));

        Date dt = Date.from(Instant.now());
        Instant instant = dt.toInstant();
        System.out.println(instant);

        LocalDateTime ldt3 = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
        System.out.println(ldt3);

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        System.out.println(calendar);
        System.out.println(calendar.getTime());




    }
}
