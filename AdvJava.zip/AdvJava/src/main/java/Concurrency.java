import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class Concurrency {
    public static void main(String ar[]) throws ExecutionException, InterruptedException, TimeoutException {
        int corePool = Runtime.getRuntime().availableProcessors();
        System.out.println("cores "+ corePool);
        ExecutorService executorService = Executors.newFixedThreadPool(corePool);

        // with callable
        Future <Integer> future = executorService.submit(() -> {
            System.out.println("Thread calling ");
            return new Random().nextInt();
        });

        //
        System.out.println(future.isDone());
        try {
            Integer op = future.get(5, TimeUnit.SECONDS);
            System.out.println("op1 "+ op);
        } catch (Exception e) {
            e.printStackTrace();
        }

        future = executorService.submit(new MyCallable());
        Integer op = future.get(5, TimeUnit.SECONDS);
        System.out.println("op2 "+ op);
        for (int i = 0; i < 4; i++) {
            Thread thread = new Thread(new MyThread());
            Future f = executorService.submit(thread);
        }
    }
}
