import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class StackQueue {
    public static void main (String ar[]) {
        System.out.println("sTACK");
        Stack<Integer> st = new Stack<>();
        st.add(1);
        st.add(2);
        st.add(3);

        System.out.println(st.peek());
        Integer poped = st.pop();
        System.out.println(poped);
        System.out.println(st);
        System.out.println(st.isEmpty());

        // Queue impl with Linked List
        System.out.println("Queue");
        Queue<Integer> queue = new LinkedList<>();
        queue.add(1);
        queue.add(2);
        queue.add(3);

        System.out.println(queue);
        System.out.println(queue.peek());

        System.out.println(queue.poll());
        System.out.println(queue);

        System.out.println(queue.isEmpty());
        System.out.println(queue.remove());
        System.out.println(queue);
    }
}
