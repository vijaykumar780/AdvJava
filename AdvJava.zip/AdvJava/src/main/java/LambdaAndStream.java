import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class LambdaAndStream {
    public static void main(String [] ar) {
        String str [] = {"ab", "lm", "wp", "dw", "vf", "dd", "qa"};
        List<String> strList = Arrays.asList(str);
        List<String> f1 = strList.stream()
                .filter(v-> (v.startsWith("a") || v.contains("d")))
                .collect(Collectors.toList());
        System.out.println(f1);

        List<String> f2 = strList.stream()
                .filter(v-> (v.startsWith("a") || v.contains("d")))
                .map(v->v.concat(" concat"))
                .collect(Collectors.toList());
        System.out.println(f2);

        Optional<String> stringOptional = strList.stream()
                .filter(v-> (v.startsWith("a") || v.contains("d")))
                        .findFirst();
        System.out.println(stringOptional.isPresent() ? stringOptional.get() : null);

        List<String> f3= strList.stream()
                .filter(v-> (v.startsWith("a") || v.contains("d") || v.contains("l")))
                .sorted()
                .collect(Collectors.toList());
        System.out.println(f3);

        List<String> f4 = strList.stream()
                .filter(v-> (v.startsWith("a") || v.contains("d")))
                .sorted(Comparator.reverseOrder())
                .collect(Collectors.toList());
        System.out.println(f4);

        List<String> f5 = strList.stream()
                .filter(v-> (v.startsWith("a") || v.contains("d")))
                .limit(1)
                .collect(Collectors.toList());
        System.out.println(f5);

        System.out.println(strList.stream().anyMatch(v->v.contains("d")));

        List<Integer> lst = new LinkedList<>();
        lst.add(1);
        lst.add(2);
        lst.add(3);

        Integer sum = lst.stream().reduce(0, (a,b)->a+b);
        Integer sum2 = lst.stream().reduce(0, Integer::sum);
        System.out.println(sum);
        System.out.println(sum2);
    }
}
