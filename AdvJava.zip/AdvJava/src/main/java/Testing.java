import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

public class Testing {

    public  static  void  main(String [] ar) throws ParseException, IOException {
        Date todayDate = new Date();
        int numOfRecords = todayDate.getYear() * 12 + todayDate.getMonth() - 121 * 12 - 8;
        System.out.println(numOfRecords);
        Double d = Double.parseDouble("175.6");
        System.out.println(Math.round(d) + 0.0);
        double doub = 50.0;
        Double roundDbl = Math.round(doub * 10.0) / 10.0;
        System.out.println(roundDbl.longValue());
        System.out.println(Math.round(doub));

        LocalDate localDate = LocalDate.of(2021, 12, 18);
        localDate = localDate.plusDays(18);
        System.out.println("w) " + localDate);

        SimpleDateFormat outputFormatter = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new SimpleDateFormat("dd/MM/yyyy").parse("12/10/2021");
        System.out.println(date);
        System.out.println(new Date(2022, 11, 6));
        System.out.println(outputFormatter.format(date));

        abc ab = new abc(null);
        Double db = ab.getD();

        if (db != null && db == null) {
            System.out.println("abc");
        }

        List<abc> list = new ArrayList<>();
        list.add(new abc(80.0));
        list.add(new abc(50.0));
        list.sort((o1, o2) -> o1.getD() >= o2.getD() ? -1 : 1);
        System.out.println(list);
        Date dt = new Date();
        System.out.println(dt + " " + dt.toInstant().toEpochMilli());
        System.out.println(Arrays.asList("1", "2").contains(null));
        System.out.println(Objects.equals("1", "1"));

        Double dbl = new Double("87500");
        System.out.println(((dbl / 100.0) * 100) / 100);
        Double accountBalance = dbl / 100.0;
        accountBalance = Math.round(accountBalance * 100.0) / 100.0;
        System.out.println(accountBalance);
        System.out.println("CommonConstants".equalsIgnoreCase(null));

        String resposne = "[\n" +
                "    {\n" +
                "        \"code\": \"163\",\n" +
                "        \"message\": \"Unknown Error Code\",\n" +
                "        \"description\": \"No match found for the requested search key \"\n" +
                "    }\n" +
                "]";


        String dt1 = "28-Feb-22";
        System.out.println(dt1.contains("-"));

        System.out.println("Param " + getDirsEncryptedParam("7039943132", "HT2332I000113636"));
        DecimalFormat decimalFormatter = new DecimalFormat("#,##,##,##0.00");
        System.out.println("Decimal " + decimalFormatter.format(new Double("0.00")));
        OffsetDateTime odt = OffsetDateTime.parse("2022-07-12T00:00:00.000+05:30");
        Instant instant = odt.toInstant();
        System.out.println("Epoch " + instant.getEpochSecond());
        System.out.println("double " + new Double("-150.05"));

        LocalDate epoToDate = Instant.ofEpochMilli(Instant.now().toEpochMilli()).atZone(ZoneId.systemDefault()).toLocalDate();
        System.out.println(epoToDate);
        System.out.println("Date:" + date);

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 5);

        System.out.println(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX").parse("2022-04-25T22:00:02.253+05:30"));
        System.out.println(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX").parse("2023-02-26T00:00:00.000+05:30").getTime());
        System.out.println(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").format(cal.getTime()));
        System.out.println(LocalDateTime.now().toString());
        // System.out.println(HostNameResolver.getHostName());
        System.out.println(Math.round(-100.87324682364 * 100D)/100D);
        Calendar cale = Calendar.getInstance();
        cale.set(2023,2,6); // mar
        cale.add(Calendar.MONTH, -1); // feb

        System.out.println(cale.getTime().getMonth());
        System.out.println(cale.getTime().getYear());
        System.out.println(cale.getTime());
        System.out.println(new ArrayList<>());
        Date dt11 = new SimpleDateFormat("dd/MM/yyyy").parse("27/04/2023");
        SimpleDateFormat outputFormatter2 = new SimpleDateFormat("dd-MMM-yyyy");
        System.out.println(outputFormatter2.format(dt11));

        LocalDate billMonthYear = LocalDate.parse("15/12/2023", DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        String billMonthYearString = DateTimeFormatter.ofPattern("MMM/yy").format(billMonthYear).replace("/","'");
        System.out.println("billMonthYearString "+ billMonthYearString);

        System.out.println("-----------------------");
        List<String> lst = new ArrayList<>();
        fileReading(lst);
        lst.forEach(item -> {
            System.out.println(getOp(item)+",");
        });
        System.out.println(lst.size());
    }





    private static String getDirsEncryptedParam(String accountId, String invoiceNumber) {
        LinkedList<String> a = new LinkedList<>();
        String strTime = new Date().getTime() + "";
        String strKey = accountId + "@!@" + invoiceNumber + "@!@" + strTime;
        String key = "365DG5ETU4H566==";
        int len = key.length();
        int KeyPos = -1;
        int offset = (int) (Math.random() * 10000.0D) % 255 + 1;
        StringBuilder dest = new StringBuilder(Integer.toHexString(offset));
        if (dest.length() == 1) {
            dest.insert(0, "0");
        }
        for (int SrcPos = 0; SrcPos < strKey.length(); SrcPos++) {
            int ascii = strKey.substring(SrcPos, SrcPos + 1).charAt(0);
            int SrcAsc = (ascii + offset) % 255;
            if (KeyPos < len - 1) {
                KeyPos++;
            } else {
                KeyPos = 0;
            }
            ascii = key.substring(KeyPos, KeyPos + 1).charAt(0);
            SrcAsc ^= ascii;
            if (SrcAsc <= 15) {
                dest.append(" ").append(Integer.toHexString(SrcAsc));
            } else {
                dest.append(Integer.toHexString(SrcAsc));
            }
            offset = SrcAsc;
        }
        strKey = dest.toString().toUpperCase();
        return strKey;
    }

    static String getOp(String id) {
        return "{\n" +
                "    \"dispatchStatus\": \"SENT_FAILED\",\n" +
                "    \"smsDispatchStatus\":\"SCHEDULED\",\n" +
                "    \"homesId\": \""+id+"\",\n" +
                "    \"billMonth\": \"May\",\n" +
                "    \"billYear\": \"2023\",\n" +
                "    \"inactive\": false,\n" +
                "    \"nextRetryTime\": {\n" +
                "        \"$date\": \"2023-05-12T07:46:59.155Z\"\n" +
                "    },\n" +
                "    \"smsNextRetryTime\": {\n" +
                "        \"$date\": \"2023-05-12T07:46:59.155Z\"\n" +
                "    },\n" +
                "    \"billGenerationDay\": \"18\",\n" +
                "    \"retryCount\": 1,\n" +
                "    \"smsRetryCount\":1\n" +
                "}";
    }

    private static void fileReading(List <String> ls) throws IOException {
        try  {
            List<String> lst = new ArrayList<>();
            FileReader fileReader = new FileReader("/Users/b0224854/Downloads/homes_billing_profiles_18_may_false.csv");
            BufferedReader br = new BufferedReader(fileReader);
            String line;
            while ((line = br.readLine()) !=null) {
                ls.add(line);
            }
            fileReader.close();
        } catch (Exception e ) {
            throw  e;
        }
    }


    static class abc {
        Double d;

        abc (Double ip) {
            this.d = ip;
        }
        public void setD(Double dd) {
            this.d = dd;
        }

        public Double getD() {
            return this.d;
        }

        @Override
        public String toString() {

            return String.valueOf(d);
        }
    }
}
